package cache

import (
	"testing"
)

func TestMain(m *testing.M) {
	m.Run()
}
