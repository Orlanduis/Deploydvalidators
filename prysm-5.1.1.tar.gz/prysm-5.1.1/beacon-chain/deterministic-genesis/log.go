package interopcoldstart

import (
	"github.com/sirupsen/logrus"
)

var log = logrus.WithField("prefix", "deterministic-genesis")
