package filesystem

import "github.com/sirupsen/logrus"

var log = logrus.WithField("prefix", "filesystem")
