package blocks

var ProcessBLSToExecutionChange = processBLSToExecutionChange

var VerifyBlobCommitmentCount = verifyBlobCommitmentCount
