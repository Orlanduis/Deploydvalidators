package electra

import "github.com/prysmaticlabs/prysm/v5/beacon-chain/core/altair"

var (
	ProcessAttestationsNoVerifySignature = altair.ProcessAttestationsNoVerifySignature
)
