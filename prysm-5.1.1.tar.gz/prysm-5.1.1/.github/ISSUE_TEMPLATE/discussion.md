---
name: "\U0001F48EGeneral issue / discussion"
about: Any other type of general issue or discussion

---
<!--💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎

Hellooo! 😄 

To help us tend to your issue faster, please search our currently open issues before submitting a new one.
Existing issues often contain information about workarounds, resolution, or progress updates.

💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎💎-->

# 💎 Issue

### Background

<!-- ✍️--> Context and background information on the discussion...

### Description
